## Human Activity Recognization using smartphone data
**The dataset is divided into two: train and test**
- link to dataset 
- [train.csv](https://drive.google.com/drive/u/0/folders/1jWSQY1ydIet94zQBqB5vjo0-XtkUOztb)
- [test.csv](https://drive.google.com/drive/u/0/folders/13oQ82pTJekjC1cZwi5d7pDiDOlIAOTd4)
